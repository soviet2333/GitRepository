create procedure asd(id in number,money in number) /*屁股后面可以加返回值:return类型*/
is
  --声明一个变量，记录涨薪前的工资
  raiseBefor number;
begin
  select sal into raiseBefor from emp where empno = id;
  dbms_output.put_line('涨薪前'||raiseBefor);
  update emp set sal = sal+money where empno = id;
  dbms_output.put_line('涨薪后'||(raiseBefor+money));
  commit;
end;
/

