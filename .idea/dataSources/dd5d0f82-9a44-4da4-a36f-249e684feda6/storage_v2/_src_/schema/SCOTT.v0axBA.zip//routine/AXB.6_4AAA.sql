create function axb(id in number) return number
is
  --声明一个变量，记录涨薪前的工资
  nianXin number;
begin
  select (sal*12+nvl(comm,0)) into nianXin from emp where empno = id;
  return nianXin;
end;
/

