create trigger INSERTBEFOR
  before insert
  on DEPT
declare

begin
  dbms_output.put_line('欢迎');
end;
/

